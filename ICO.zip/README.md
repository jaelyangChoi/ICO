# ICO Service (Individual Custom cOmments)
|직책|이름|
|:---:|:---:|
|팀장|최재량|
|팀원|김하경|
|팀원|송윤재|
|팀원|안나연|
|팀원|정혜원|

